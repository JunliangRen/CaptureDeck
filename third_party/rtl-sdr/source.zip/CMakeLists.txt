cmake_minimum_required(VERSION 3.21)
project(CaptureRackRtlRuntime LANGUAGES C RC)
set(CMAKE_MSVC_RUNTIME_LIBRARY MultiThreaded)
set(usb "${CMAKE_CURRENT_SOURCE_DIR}/libusb-1.0.29")
set(rtl "${CMAKE_CURRENT_SOURCE_DIR}/rtl-sdr-619ac3186ea0ffc092615e1f59f7397e5e6f668c")
add_library(libusb-1.0 SHARED
    ${usb}/libusb/core.c ${usb}/libusb/descriptor.c ${usb}/libusb/hotplug.c
    ${usb}/libusb/io.c ${usb}/libusb/strerror.c ${usb}/libusb/sync.c
    ${usb}/libusb/os/events_windows.c ${usb}/libusb/os/threads_windows.c
    ${usb}/libusb/os/windows_common.c ${usb}/libusb/os/windows_usbdk.c
    ${usb}/libusb/os/windows_winusb.c ${usb}/libusb/libusb-1.0.def
    ${usb}/libusb/libusb-1.0.rc)
target_include_directories(libusb-1.0 PRIVATE ${usb}/msvc PUBLIC ${usb}/libusb)
target_compile_definitions(libusb-1.0 PRIVATE _WIN32_WINNT=0x0600 _CRT_SECURE_NO_WARNINGS)
add_library(rtlsdr SHARED ${rtl}/src/librtlsdr.c ${rtl}/src/tuner_e4k.c
    ${rtl}/src/tuner_fc0012.c ${rtl}/src/tuner_fc0013.c
    ${rtl}/src/tuner_fc2580.c ${rtl}/src/tuner_r82xx.c)
target_include_directories(rtlsdr PRIVATE ${rtl}/include)
target_link_libraries(rtlsdr PRIVATE libusb-1.0)
target_compile_definitions(rtlsdr PRIVATE _CRT_SECURE_NO_WARNINGS)
